#!/bin/bash

cd .
pwd
../common_files/sbhsclient
