dat = [t y u];
save -ASCII figures/ball_1aux.dat dat
