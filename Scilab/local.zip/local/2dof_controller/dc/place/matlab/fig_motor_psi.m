dat = [t poly_y poly_u];
save -ASCII figures/motor_psi.dat dat
