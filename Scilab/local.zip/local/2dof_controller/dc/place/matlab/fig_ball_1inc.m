dat = [t y u];
save -ASCII figures/ball_1inc.dat dat
