dat = [t u usat y];
save -ASCII figures/nosat_noawc.dat dat
