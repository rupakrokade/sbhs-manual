dat = [t u usat y];
save -ASCII figures/nosat_awc.dat dat
