dat = [t y u];
save -ASCII figures/ibm.dat dat
