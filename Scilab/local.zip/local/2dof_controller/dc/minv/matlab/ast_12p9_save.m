D = [1 -1.7 0.7]; dD = 2;
N = [0 0.9 1]; dN = 2;
C = [1 0.2 -0.63]; dC = 2;
[S,dS,R,dR] = xdync(N,dN,D,dD,C,dC)
