function b = flip(a)
b = a(length(a):-1:1);
