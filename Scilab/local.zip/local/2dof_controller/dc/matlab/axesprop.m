function axesprop(fs)
%This function sets the font size of the axes labels(XTickLabel and 
%YTickLabel)
A = axes('FontSize',fs);

