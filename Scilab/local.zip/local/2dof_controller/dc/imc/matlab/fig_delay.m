dat = [t y u];
save -ASCII figures/delay.dat dat
