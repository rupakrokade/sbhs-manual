dat = [t y u];
save -ASCII figures/vande_ap5.dat dat
