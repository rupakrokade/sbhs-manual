dat = [t y u];
save -ASCII figures/nodelay.dat dat
