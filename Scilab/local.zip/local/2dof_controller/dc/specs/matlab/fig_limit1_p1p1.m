dat = [t y u];
save -ASCII figures/limit1_p1p1.dat dat
