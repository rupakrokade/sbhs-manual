dat = [t y u];
save -ASCII figures/limit1_nom.dat dat
