D = [
1 0 0 0 0 0
0 1 0 1 0 0
0 0 1 1 1 0]
N = [
1 0 0
0 1 0
0 0 1]
dD = 1
dN = 0
[B,dB,A,dA] = left_prm(N,dN,D,dD)
