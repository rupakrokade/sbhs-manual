dat = [t y u];
save -ASCII figures/ant.dat dat
