t = 0:0.01:4;
plot(t,cos(2*pi*t/8),t,cos(2*7*pi*t/8))
xlabel('t')
ylabel('coswt')
grid
% saved to the file diff.ps
