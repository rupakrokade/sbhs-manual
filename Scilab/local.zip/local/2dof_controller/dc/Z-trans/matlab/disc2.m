sys = tf(10,[5 1]);
sysd = c2d(sys,0.5);

