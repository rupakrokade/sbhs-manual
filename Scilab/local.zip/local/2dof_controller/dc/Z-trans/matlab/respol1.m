%             2z^2 + 2z
% G(z)  =  ---------------
%            z^2 + 2z - 3

num = [2 2 0];
den = [1 2 -3];
[res,pol] = respol(num,den) % respol is user defined
