u = [1 2];
r = xcov(u);
rho = xcov(u,'coeff');
