x0=rand(2,1);
z=fsolve(@weibu,x0)
