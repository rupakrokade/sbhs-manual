Please Note:

This folder contains the following:

1. Conventional Tuning_Vikas_07d02013 (folder)
2. Self Tuning_Vikas_07d02013 (folder)

In each of the two above folders, there are four folders:

a) PI Controller Fan disturbance
b) PI Controller Set point change
c) PID Controller Fan Disturbance 
d) PID Controller Set point change

Each of the above four folders has scilab codes and also an 'instruction and plot description' file which describe what they do and how to execute them. 

The codes have been tested on scilab 4.0

