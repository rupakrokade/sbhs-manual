b = input('enter value of b: ');
disc = (b^4+34*b^2+1)/4/b;
c1 = (-2*b+sqrt(disc))/4/b
c2 = (-2*b-sqrt(disc))/4/b
acos(c1)*180/pi
acos(c2)*180/pi


