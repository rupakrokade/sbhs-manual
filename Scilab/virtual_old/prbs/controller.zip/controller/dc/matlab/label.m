function label(tname,tfont,labelx,labely,xyfont)
title(tname,'fontsize',tfont)
xlabel(labelx,'fontsize',xyfont)
ylabel(labely,'fontsize',xyfont)
grid on
