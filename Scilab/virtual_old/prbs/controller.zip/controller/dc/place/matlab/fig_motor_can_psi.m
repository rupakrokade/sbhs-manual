dat = [t y u];
save -ASCII figures/motor_can_psi.dat dat
