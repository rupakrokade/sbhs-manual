dat = [t y u];
save -ASCII figures/motor.dat dat
