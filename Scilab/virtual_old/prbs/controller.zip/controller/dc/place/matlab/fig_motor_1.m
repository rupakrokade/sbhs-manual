dat = [t y u];
save -ASCII figures/motor_1.dat dat
