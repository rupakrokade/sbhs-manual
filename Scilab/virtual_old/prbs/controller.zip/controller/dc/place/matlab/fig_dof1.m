dat = [t y u];
save -ASCII figures/dof1.dat dat
