dat = [t y u];
save -ASCII figures/ball_1.dat dat
