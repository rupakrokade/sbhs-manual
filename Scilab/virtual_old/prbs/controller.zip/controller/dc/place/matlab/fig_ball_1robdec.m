dat = [t y u];
save -ASCII figures/ball_1robdec.dat dat
