dat = [t poly_y poly_u];
save -ASCII figures/motor_can_1.dat dat
