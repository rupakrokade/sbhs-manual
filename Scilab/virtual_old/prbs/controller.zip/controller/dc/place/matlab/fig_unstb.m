dat = [t y u];
save -ASCII figures/unstb.dat dat
