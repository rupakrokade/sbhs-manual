dat = [t u usat y];
save -ASCII figures/sat_awc.dat dat
