dat = [t y u];
save -ASCII figures/track.dat dat
