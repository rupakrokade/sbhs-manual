dat = [t y u];
save -ASCII figures/regul.dat dat
