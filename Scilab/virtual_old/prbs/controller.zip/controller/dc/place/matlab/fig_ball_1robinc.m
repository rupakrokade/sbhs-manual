dat = [t y u];
save -ASCII figures/ball_1robinc.dat dat
