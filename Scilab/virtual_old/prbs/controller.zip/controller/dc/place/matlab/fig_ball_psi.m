dat = [t y u];
save -ASCII figures/ball_psi.dat dat
