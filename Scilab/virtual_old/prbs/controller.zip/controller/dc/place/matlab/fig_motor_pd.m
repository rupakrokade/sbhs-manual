dat = [t y u];
save -ASCII figures/motor_pd.dat dat
