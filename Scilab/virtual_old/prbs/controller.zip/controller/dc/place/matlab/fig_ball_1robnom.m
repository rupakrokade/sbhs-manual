dat = [t y u];
save -ASCII figures/ball_1robnom.dat dat
