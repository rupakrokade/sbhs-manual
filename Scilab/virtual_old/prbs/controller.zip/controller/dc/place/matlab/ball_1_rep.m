T = Ag; gamma = sum(phi)/sum(Bb); 
