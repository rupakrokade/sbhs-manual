dat = [t y u];
save -ASCII figures/motor_cpd.dat dat
