dat = [t y u];
save -ASCII figures/pid_neg4.dat dat
