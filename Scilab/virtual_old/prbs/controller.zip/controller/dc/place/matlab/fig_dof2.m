dat = [t y u];
save -ASCII figures/dof2.dat dat
