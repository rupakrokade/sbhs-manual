dat = [t y u];
save -ASCII figures/lewin_ap9.dat dat
