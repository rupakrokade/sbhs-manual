dat = [t y u];
save -ASCII figures/vande_ap9.dat dat
