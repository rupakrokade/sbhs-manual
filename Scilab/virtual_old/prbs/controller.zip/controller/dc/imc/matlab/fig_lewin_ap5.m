dat = [t y u];
save -ASCII figures/lewin_ap5.dat dat
