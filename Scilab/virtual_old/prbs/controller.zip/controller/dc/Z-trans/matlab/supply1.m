Ti=0.501;
A = [Ti 0 0 0 1-Ti];
abs(roots(A))

