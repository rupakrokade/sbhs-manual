H = tf(1,[1 -1 0],-1);
nyquist(H)

