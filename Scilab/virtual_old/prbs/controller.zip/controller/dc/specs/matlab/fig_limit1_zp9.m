dat = [t y u];
save -ASCII figures/limit1_zp9.dat dat
