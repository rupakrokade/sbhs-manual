dat = [t y u];
save -ASCII figures/limit1_z1p1.dat dat
