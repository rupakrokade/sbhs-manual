F = [-1 0;1 0];
expm(F)
