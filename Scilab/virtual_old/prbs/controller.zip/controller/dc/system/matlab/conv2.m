h = [1 2 3];
u = [4 5 6];
y = conv(u,h)
