h = [1 2 3];
u = [4 5];
rhu = xcorr(h,u)
ruh = xcorr(u,h)
