u = [4 5 6];
ruu = xcorr(u)
